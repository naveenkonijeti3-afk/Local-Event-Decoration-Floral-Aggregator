const express = require("express");
const cors = require("cors");
const path = require("path");
const sqlite3 = require("sqlite3").verbose();

const app = express();
const PORT = process.env.PORT || 3000;
const db = new sqlite3.Database("./data/events.db");

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS vendors (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    category TEXT NOT NULL,
    location TEXT NOT NULL,
    price INTEGER NOT NULL,
    rating REAL DEFAULT 4.5,
    image TEXT,
    description TEXT
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS bookings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_name TEXT NOT NULL,
    phone TEXT NOT NULL,
    email TEXT,
    event_type TEXT NOT NULL,
    event_date TEXT NOT NULL,
    location TEXT NOT NULL,
    vendor_id INTEGER,
    message TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);

  db.get("SELECT COUNT(*) AS count FROM vendors", (err, row) => {
    if (!err && row.count === 0) {
      const seed = db.prepare(`INSERT INTO vendors
        (name, category, location, price, rating, image, description)
        VALUES (?, ?, ?, ?, ?, ?, ?)`);

      const vendors = [
        ["Royal Bloom Decor", "Wedding Decoration", "Tirupati", 25000, 4.9,
         "https://images.unsplash.com/photo-1519225421980-715cb0215aed?auto=format&fit=crop&w=900&q=80",
         "Elegant wedding stages, entrance decoration and floral themes."],
        ["Petal House", "Floral Decoration", "Tirupati", 12000, 4.8,
         "https://images.unsplash.com/photo-1523438885200-e635ba2c371e?auto=format&fit=crop&w=900&q=80",
         "Fresh flower bouquets, garlands, mandapam flowers and table decor."],
        ["Celebration Hub", "Birthday Decoration", "Chittoor", 6500, 4.7,
         "https://images.unsplash.com/photo-1530103862676-de8c9debad1d?auto=format&fit=crop&w=900&q=80",
         "Balloon arches, birthday backdrops, cake tables and custom themes."],
        ["Dream Stage Events", "Stage Decoration", "Nellore", 18000, 4.6,
         "https://images.unsplash.com/photo-1492684223066-81342ee5ff30?auto=format&fit=crop&w=900&q=80",
         "Professional stage, lighting and backdrop decoration for events."],
        ["Green Leaf Florals", "Floral Decoration", "Chittoor", 9000, 4.8,
         "https://images.unsplash.com/photo-1490750967868-88aa4486c946?auto=format&fit=crop&w=900&q=80",
         "Natural floral arrangements and premium event flower styling."],
        ["Grand Moments", "Wedding Decoration", "Nellore", 32000, 4.9,
         "https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&w=900&q=80",
         "Complete wedding decor packages with lighting and floral design."]
      ];
      vendors.forEach(v => seed.run(v));
      seed.finalize();
    }
  });
});

// Get vendors, with optional search/category/location filters
app.get("/api/vendors", (req, res) => {
  const { search = "", category = "", location = "" } = req.query;
  let sql = "SELECT * FROM vendors WHERE 1=1";
  const params = [];

  if (search) {
    sql += " AND (name LIKE ? OR category LIKE ? OR description LIKE ?)";
    const q = `%${search}%`;
    params.push(q, q, q);
  }
  if (category) {
    sql += " AND category = ?";
    params.push(category);
  }
  if (location) {
    sql += " AND location = ?";
    params.push(location);
  }
  sql += " ORDER BY rating DESC, price ASC";

  db.all(sql, params, (err, rows) => {
    if (err) return res.status(500).json({ error: "Database error" });
    res.json(rows);
  });
});

// Create a booking request
app.post("/api/bookings", (req, res) => {
  const {
    customer_name, phone, email, event_type,
    event_date, location, vendor_id, message
  } = req.body;

  if (!customer_name || !phone || !event_type || !event_date || !location) {
    return res.status(400).json({ error: "Please fill all required fields." });
  }

  const sql = `INSERT INTO bookings
    (customer_name, phone, email, event_type, event_date, location, vendor_id, message)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)`;

  db.run(sql,
    [customer_name, phone, email || "", event_type, event_date,
     location, vendor_id || null, message || ""],
    function(err) {
      if (err) return res.status(500).json({ error: "Could not save booking." });
      res.status(201).json({
        message: "Booking request submitted successfully!",
        bookingId: this.lastID
      });
    }
  );
});

// Admin/demo endpoint for viewing bookings
app.get("/api/bookings", (req, res) => {
  db.all(`SELECT b.*, v.name AS vendor_name
          FROM bookings b LEFT JOIN vendors v ON b.vendor_id = v.id
          ORDER BY b.created_at DESC`, [], (err, rows) => {
    if (err) return res.status(500).json({ error: "Database error" });
    res.json(rows);
  });
});

app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, () => {
  console.log(`Event aggregator running on http://localhost:${PORT}`);
});