const API = "/api";
const vendorGrid = document.getElementById("vendorGrid");
const vendorSelect = document.getElementById("vendorSelect");
const vendorCount = document.getElementById("vendorCount");

async function loadVendors() {
  const search = document.getElementById("searchInput").value.trim();
  const category = document.getElementById("categoryFilter").value;
  const location = document.getElementById("locationFilter").value;

  const params = new URLSearchParams({search, category, location});
  vendorGrid.innerHTML = "<p>Loading...</p>";

  try {
    const res = await fetch(`${API}/vendors?${params}`);
    const vendors = await res.json();

    vendorCount.textContent = `${vendors.length} service${vendors.length === 1 ? "" : "s"} found`;

    if (!vendors.length) {
      vendorGrid.innerHTML = "<p>No vendors found. Try another search.</p>";
      return;
    }

    vendorGrid.innerHTML = vendors.map(v => `
      <article class="card">
        <img class="card-img" src="${v.image}" alt="${escapeHtml(v.name)}">
        <div class="card-body">
          <span class="tag">${escapeHtml(v.category)}</span>
          <h3>${escapeHtml(v.name)}</h3>
          <p class="meta">📍 ${escapeHtml(v.location)} &nbsp; <span class="rating">★ ${v.rating}</span></p>
          <p class="meta">${escapeHtml(v.description)}</p>
          <p class="price">From ₹${Number(v.price).toLocaleString("en-IN")}</p>
          <button class="btn primary" onclick="chooseVendor(${v.id})">Book this vendor</button>
        </div>
      </article>
    `).join("");

    vendorSelect.innerHTML = `<option value="">Preferred vendor (optional)</option>` +
      vendors.map(v => `<option value="${v.id}">${escapeHtml(v.name)} — ${escapeHtml(v.location)}</option>`).join("");
  } catch (err) {
    vendorGrid.innerHTML = "<p>Could not connect to the server. Start the backend with npm start.</p>";
  }
}

function chooseVendor(id) {
  vendorSelect.value = String(id);
  document.getElementById("booking").scrollIntoView({behavior:"smooth"});
}

document.getElementById("bookingForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const message = document.getElementById("formMessage");
  const data = Object.fromEntries(new FormData(e.target).entries());

  message.textContent = "Submitting...";
  message.style.color = "#3d6b50";

  try {
    const res = await fetch(`${API}/bookings`, {
      method: "POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify(data)
    });
    const result = await res.json();

    if (!res.ok) throw new Error(result.error || "Something went wrong");

    message.textContent = `✓ ${result.message} Booking ID: ${result.bookingId}`;
    e.target.reset();
  } catch (err) {
    message.textContent = `✕ ${err.message}`;
    message.style.color = "#b23a3a";
  }
});

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, c => ({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"
  }[c]));
}

loadVendors();